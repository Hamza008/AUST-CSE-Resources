#include <bits/stdc++.h>
using namespace std;

int vertex, edge;
const int inf = 9999;

struct node
{
    int cost, parent, weight[100];
    bool isConnected[100];
    node()
    {
        cost=inf;
    }
} G[100];

bool BellmanFord()
{
    int value;
    bool flag;
    for(int i=1; i<=vertex; i++)
    {
        flag = false;
        for(int j=1; j<=vertex; j++)
        {
            for(int k=1; k<=vertex; k++)
            {
                if(G[j].isConnected[k]==true)
                {
                    value=G[j].cost + G[j].weight[k];
                    if(G[k].cost>value)
                    {
                        if(i==vertex)
                        {
                            return false;
                        }
                        else
                        {
                            G[k].cost=value;
                            flag=true;
                        }
                    }
                }
            }
        }
        if(flag==false)
        {
            return true;
        }
    }
    return true;
}

int main()
{
    ifstream infile;
    infile.open("input.txt");
    infile >> vertex >> edge;

    int j, k, m;
    for(int i=1; i<=edge; i++)
    {
        infile >> j >> k >> m;
        G[j].isConnected[k]=true;
        G[j].weight[k]=m;
    }

    G[1].cost=0;
    if(BellmanFord()==true)
    {
        cout << G[5].cost;
    }else{
        cout << "Negetive Cycle";
    }


    return 0;
}
