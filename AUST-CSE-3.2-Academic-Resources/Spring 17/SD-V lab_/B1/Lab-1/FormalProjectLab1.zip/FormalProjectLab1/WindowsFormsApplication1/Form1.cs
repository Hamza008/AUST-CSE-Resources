﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class NameBox : Form
    {

        String type;
        int res, a, b;

        public NameBox()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(num.Text);

            type = "add";

            num.Text = " ";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (type == "add")
            {
                b = Convert.ToInt32(num.Text);
                res = a + b;

               
            }
            else if (type == "sub")
            {
                b = Convert.ToInt32(num.Text);
                res = a - b;

                
            }
            else if (type == "mul")
            {
                b = Convert.ToInt32(num.Text);
                res = a*b;

              
            }
            else if (type == "div")
            {
                b = Convert.ToInt32(num.Text);
                res = a/b;
            }

            num.Text = Convert.ToString(res);
        }

        private void Sub_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(num.Text);

            type = "sub";

            num.Text = " ";
        }

        private void Mul_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(num.Text);

            type = "mul";

            num.Text = " ";
        }

        private void Div_Click(object sender, EventArgs e)
        {
            a = Convert.ToInt32(num.Text);

            type = "div";

            num.Text = " ";
        }

        private void Clear_Click(object sender, EventArgs e)
        {
            num.Text = " ";
        }

        

        
    }
}
