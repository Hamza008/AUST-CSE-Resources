/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UsrInterface;

/**
 *
 * @author Sera
 */
public class Student {
    private String firstName;
    private int year;
    
    private String lastName;

    /**
     * @return the firstName
     */
    public Student(String firstName, int year, String lastName) {
        this.firstName = firstName;
        this.year = year;
        this.lastName = lastName;
    }


    public String getFirstName() {
        return firstName;
    }

    /**
     * @return the year
     */
    public int getYear() {
        return year;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }
    
}
