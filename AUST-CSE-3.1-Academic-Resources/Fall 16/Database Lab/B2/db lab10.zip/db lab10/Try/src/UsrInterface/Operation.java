/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package UsrInterface;

import java.sql.ResultSet;
import java.sql.SQLException;
import UsrInterface.Student;
/**
 *
 * @author Sera
 */
public class Operation {
    private DBConnect dbc;
    private ResultSet rs; 
    
    //public void Operation() throws SQLException
    public void Operation()
    {
        //dbc = new DBConnect();
        //rs = null;               
    }
    
    public void saveInvoice(Student stu) throws ClassNotFoundException
    {   System.out.println("ghk ");       
        try{
         dbc = new DBConnect();
         dbc.connectToDB();   
         
         String pp = stu.getFirstName();
         String p1 = stu.getLastName();
         Integer y = stu.getYear();
         System.out.println("firstname "+ pp);
         System.out.println("lastname "+ p1);
         System.out.println("year "+ y);

         //Boolean dataSaved = dbc.insertDataToDB("INSERT INTO Student(firstName, lastName, year)"
          //                                  + " VALUES("+stu.getFirstName()+", "+stu.getLastName()+", "+stu.getYear()+")");
         Boolean dataSaved = dbc.insertDataToDB("INSERT INTO student(firstName, lastName, year)"
                                            + " VALUES('"+stu.getFirstName()+"', '"+stu.getLastName()+"', "+stu.getYear()+")");
                              
         System.out.println("save or not "+ dataSaved);
         dbc.disconnectFromDB();            
     }
       catch (SQLException ex) {
            System.out.println(ex.getMessage());
            
        }finally {closeDB();}

    } 
    
 private void closeDB()
{
    try{
        if (rs != null){rs.close();}
       // if (stmt != null){stmt.close();}
        //if (dbc != null){dbc.close();}
    }catch(Exception e){}
}
}
