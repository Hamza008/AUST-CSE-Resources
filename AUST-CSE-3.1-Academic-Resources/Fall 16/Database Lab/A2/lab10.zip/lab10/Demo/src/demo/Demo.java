
package demo;

import java.sql.Connection;  
 import java.sql.DriverManager;  
 import java.sql.ResultSet;  
 import java.sql.Statement;  
 import java.*; 
import java.sql.*;
public class Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {  
             Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
             Connection connection = DriverManager.getConnection("jdbc:sqlserver://localhost:1433;databaseName=lab10;integratedSecurity=true");  
   
               Statement statement = connection.createStatement();  
               
             ResultSet resultSet = statement  
                     .executeQuery("SELECT acc_no  FROM customer");  
             while (resultSet.next()) {  
                 System.out.println(resultSet.getString("acc_no") );  
                // new testing().setVisible(true); 
                 new front_page().setVisible(true);
                 
                 
                 
                 
             }  
             
         } catch (Exception e) {  
             e.printStackTrace();  
         }  
    }
    
}
