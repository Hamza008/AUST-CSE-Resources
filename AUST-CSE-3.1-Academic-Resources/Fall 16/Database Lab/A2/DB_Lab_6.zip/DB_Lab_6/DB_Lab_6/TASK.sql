/* 1. Find the total sum of assets of street no. 51a */

select SUM(assets)
from branch
where Street= '51a';

/* 2. Find the total balance of branches whose street is 51a  */

select SUM(Balance)
from Account, branch
where branch.Street='51a'
and Account.Branch_Name=branch.branch_name;

/* 3. Find the number of customers whose balance is greater than 10000 */

select COUNT(acc_no)
from account
where balance > 10000;


/* 4. Find the Customer id, name and city of the customer whose opening_date is '15/02/2004' */

select a.Cus_id,a.Cus_Name,a.City
from customer as a, depositor as b
where a.cus_id= b.cus_id
and b.opening_date='15/02/2004';

/* 5. Find the avg balance of each branch having total balance greater than 38000 */

select branch_name,AVG(balance) as total_balance
from account
group by branch_name
having AVG(balance) > 38000;
 

/* 6. Find the customer_id, account_number,balance for all the customers who has an account at 'Dhanmondi' branch. */

select b.cus_id,a.acc_no, a.balance
from account as a,depositor as b
where a.acc_no=b.acc_no
and a.branch_name='dhanmondi';
 
/* 7. Find the name of the customer who has an account at 'Dhanmondi' branch */

SELECT DISTINCT Cus_Name 
FROM Customer, Depositor, Account
WHERE Customer.Cus_id = Depositor.Cus_id 
AND Account.acc_no = Depositor.acc_no 
AND Account.Branch_Name = 'Dhanmondi';
